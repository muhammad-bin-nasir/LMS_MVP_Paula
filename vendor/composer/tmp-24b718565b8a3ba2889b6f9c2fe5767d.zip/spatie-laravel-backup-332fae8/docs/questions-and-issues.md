---
title: Questions & issues
weight: 6
---

Find yourself stuck using the package? Found a bug? Do you have general questions or suggestions for improving the backup package? Feel free to [create an issue on GitHub](https://github.com/spatie/laravel-backup/issues), we'll try to address it as soon as possible.

If you've found a bug regarding security please mail [freek@spatie.be](mailto:freek@spatie.be) instead of using the issue tracker.
