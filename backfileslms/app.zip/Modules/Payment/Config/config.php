<?php

return [
    'name' => 'Payment'
];
